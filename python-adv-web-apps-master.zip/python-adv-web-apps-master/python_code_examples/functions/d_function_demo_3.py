# this function has two parameters, and it returns a value

def drink_expenses(price, count):
   total = price * count
   return total

# call the function with two arguments
drink_expenses(4.49, 5)
