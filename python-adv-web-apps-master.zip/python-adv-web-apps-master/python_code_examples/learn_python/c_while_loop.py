word = "spam"

while word == "spam":
    print("Spam spam spam spam")
    print("Type the word spam.")
    word = input()

print("No more spam 😥")
