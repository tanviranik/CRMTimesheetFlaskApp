# Flask Databases

See:

* [Flask and Databases](https://python-adv-web-apps.readthedocs.io/en/latest/flask_db1.html)
* [Flask: Read from a Database](https://python-adv-web-apps.readthedocs.io/en/latest/flask_db2.html)
* [Flask: Write to a Database](https://python-adv-web-apps.readthedocs.io/en/latest/flask_db3.html)

Also see:

[Building a select menu in a form](https://bit.ly/mm-flask-select)
