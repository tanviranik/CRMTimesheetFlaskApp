# Flask app: Presidents

This app is discussed in the [Flask Templates chapter](https://python-adv-web-apps.readthedocs.io/en/latest/flask3.html#) of **Python Beginners.**

A live version of this app can be viewed here:

https://weimergeeks.com/flask_pres/

.
