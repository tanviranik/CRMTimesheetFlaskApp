# Flask app: first-baby-flask-app

This app is discussed in the [Flask Templates chapter](https://python-adv-web-apps.readthedocs.io/en/latest/flask3.html#) of **Python Beginners.**

A live version of this app can be viewed here:

https://first-baby-flask-app.herokuapp.com/ 

.
