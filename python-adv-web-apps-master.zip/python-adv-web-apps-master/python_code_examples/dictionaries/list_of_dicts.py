"""a list of dictionaries"""

hugo_winners = [
    {'Title': 'The Three-Body Problem', 'Author': 'Cixin Liu', 'Year': '2015'},
    {'Title': 'Ancillary Justice', 'Author': 'Ann Leckie', 'Year': '2014'},
    {'Title': 'Redshirts', 'Author': 'John Scalzi', 'Year': '2013'},
    {'Title': 'Among Others', 'Author': 'Jo Walton', 'Year': '2012'},
    {'Title': 'Blackout-All Clear', 'Author': 'Connie Willis', 'Year': '2011'},
    {'Title': 'The City & the City', 'Author': 'China Mieville', 'Year': '2010'},
    {'Title': 'The Windup Girl', 'Author': 'Paolo Bacigalupi', 'Year': '2010'},
    {'Title': 'The Graveyard Book', 'Author': 'Neil Gaiman', 'Year': '2009'},
    {'Title': "The Yiddish Policemen's Union", 'Author': 'Michael Chabon', 'Year': '2008'},
    {'Title': 'Rainbows End', 'Author': 'Vernor Vinge', 'Year': '2007'},
    {'Title': 'Spin', 'Author': 'Robert Charles Wilson', 'Year': '2006'},
    {'Title': 'Jonathan Strange & Mr Norrell', 'Author': 'Susanna Clarke', 'Year': '2005'},
    {'Title': 'Paladin of Souls', 'Author': 'Lois McMaster Bujold', 'Year': '2004'},
    {'Title': 'Hominids', 'Author': 'Robert J. Sawyer', 'Year': '2003'},
    {'Title': 'American Gods', 'Author': 'Neil Gaiman', 'Year': '2002'},
    {'Title': 'Harry Potter and the Goblet of Fire', 'Author': 'J. K. Rowling', 'Year': '2001'},
    {'Title': 'A Deepness in the Sky', 'Author': 'Vernor Vinge', 'Year': '2000'},
    {'Title': 'To Say Nothing of the Dog', 'Author': 'Connie Willis', 'Year': '1999'},
    {'Title': 'Forever Peace', 'Author': 'Joe Haldeman', 'Year': '1998'},
    {'Title': 'Blue Mars', 'Author': 'Kim Stanley Robinson', 'Year': '1997'}
]
