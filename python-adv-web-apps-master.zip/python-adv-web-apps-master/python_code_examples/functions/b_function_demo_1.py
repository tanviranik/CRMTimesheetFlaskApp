# this function has no parameters and returns nothing

def drink_expenses():
    price = 3.99
    count = 7
    total = price * count

# call the function
drink_expenses()
