# this function has two parameters, but it returns nothing

def drink_expenses(price, count):
    total = price * count

# call the function with two arguments
drink_expenses(3.99, 7)
